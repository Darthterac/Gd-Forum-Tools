let table = new DataTable("#characters", {
    columnDefs: [
        { targets: 0, orderable: false }
    ]
});

//---------------------------------------

const CLASS_COLORS = {
    WARRIOR: "#C79C6E",
    PALADIN: "#F58CBA",
    HUNTER: "#ABD473",
    ROGUE: "#FFF569",
    PRIEST: "#FFFFFF",
    DEATHKNIGHT: "#C41F3B",
    SHAMAN: "#0070DE",
    MAGE: "#69CCF0",
    WARLOCK: "#9482C9",
    MONK: "#00FF96",
    DRUID: "#FF7D0A",
    DEMONHUNTER: "#A330C9",
    EVOKER: "#33937F"
};

document.getElementById("loadBtn").addEventListener("click", fetchProfile);
document.getElementById("userInput").addEventListener("keypress", function(e) {
    if (e.key === "Enter") fetchProfile();
});

function fetchProfile()
{
    let inputVal = document.getElementById("userInput").value.trim();
    if (!inputVal) return;

    // Clean up input if they pasted a full URL instead of just the user card
    // e.g. https://us.forums.blizzard.com/en/wow/u/panthra-2938857.json -> panthra-2938857
    try
    {
        if (inputVal.startsWith("http"))
        {
            const urlObj = new URL(inputVal);
            const segments = urlObj.pathname.split("/").filter(Boolean);
            const uIndex = segments.indexOf("u");
            if (uIndex !== -1 && segments[uIndex + 1])
            {
                inputVal = segments[uIndex + 1].replace(".json", "");
            }
        }
    }
    catch (err)
    {
        // Fallback if parsing fails
    }

    const apiUrl = `https://us.forums.blizzard.com/en/wow/u/${inputVal}.json`;

    fetch(apiUrl)
        .then(res => {
            if (!res.ok) throw new Error("Profile not found");
            return res.json();
        })
        .then(data => {
            parse(data);
        })
        .catch(err => {
            alert("Could not load profile. Check the user card or URL and try again.");
            console.error(err);
        });
}

function parse(data)
{

    table.clear();

    const user = data.user || data;

    document.getElementById("username").textContent =
        user.username;

    //---------------------------------------

    let highestTrust = user.trust_level || user.trustLevel || 0;

    // Fall back to highest trust_level_N group the user belongs to
    if (!highestTrust && user.groups)
    {
        for (const group of user.groups)
        {
            const groupName = typeof group === 'string' ? group : (group.name || "");
            const match = /^trust_level_(\d+)$/.exec(groupName);

            if (match)
                highestTrust = Math.max(highestTrust, Number(match[1]));
        }
    }

    document.getElementById("trust").textContent =
        highestTrust;

    //---------------------------------------

    document.getElementById("memberSince").textContent =
        formatDate(user.created_at);

    document.getElementById("lastActive").textContent =
        formatDate(user.last_seen_at);

    //---------------------------------------

    let selectedCharacter = "-";
    let totalLevel = 0;
    let totalAp = 0;
    let classCounts = {};

    // Handles both user_aliases and aliases depending on endpoint structure
    const aliases = user.user_aliases || user.aliases || [];

    for (const character of aliases)
    {

        if (character.selected)
            selectedCharacter = character.name;

        const fields = character.alias_custom_fields || [];

        const guild = fields.find(x => x.name === "guild")?.value || "";
        const realm = fields.find(x => x.name === "realm")?.value || "";
        const level = fields.find(x => x.name === "level")?.value || "";
        const race = fields.find(x => x.name === "race")?.value || "";
        const playerClass = fields.find(x => x.name === "player_class")?.value || "";
        const playerClassEnum = fields.find(x => x.name === "player_class_enum")?.value || "";
        const achievementPoints = fields.find(x => x.name === "achievement_points")?.value || "0";
        const profileUrl = fields.find(x => x.name === "profile_url")?.value || character.url || "";

        const nameCell = buildNameCell(character.name, profileUrl);
        const raceClassCell = buildRaceClassCell(race, playerClass, playerClassEnum);
        const portraitCell = buildPortraitCell(character.avatar);

        totalLevel += Number(level) || 0;
        totalAp += Number(achievementPoints) || 0;

        if (playerClass)
        {
            if (!classCounts[playerClass])
                classCounts[playerClass] = { count: 0, classEnum: playerClassEnum };

            classCounts[playerClass].count++;
        }

        table.row.add([

            portraitCell,

            character.selected ? "<span class=\"selected-mark\">\u2714</span>" : "",

            nameCell,

            raceClassCell,

            realm,

            Number(level),

            Number(achievementPoints) || 0,

            guild

        ]);

    }

    document.getElementById("selected").textContent =
        selectedCharacter;

    //---------------------------------------

    const characterCount = aliases.length;

    document.getElementById("rosterCount").textContent =
        characterCount;

    document.getElementById("rosterAvgLevel").textContent =
        characterCount ? (totalLevel / characterCount).toFixed(1) : "-";

    document.getElementById("rosterTotalAp").textContent =
        totalAp.toLocaleString();

    let topClass = "-";
    let topClassCount = 0;
    let topClassEnum = "";

    for (const className in classCounts)
    {
        if (classCounts[className].count > topClassCount)
        {
            topClass = className;
            topClassCount = classCounts[className].count;
            topClassEnum = classCounts[className].classEnum;
        }
    }

    document.getElementById("rosterTopClass").innerHTML =
        topClass === "-" ? "-" : classNameHtml(topClass, topClassEnum);

    table.draw();

}

//---------------------------------------

function buildNameCell(fullName, profileUrl)
{
    let region = "us";
    let realmSlug = "";
    let nameSlug = "";

    try
    {
        const segments = new URL(profileUrl).pathname.split("/").filter(Boolean);
        const idx = segments.indexOf("character");

        if (idx !== -1 && segments.length >= idx + 4)
        {
            region = segments[idx + 1];
            realmSlug = segments[idx + 2];
            nameSlug = segments[idx + 3];
        }
    }
    catch (e) {}

    let decodedName = nameSlug;
    try
    {
        decodedName = decodeURIComponent(nameSlug);
    }
    catch (e) {}

    const displayName =
        decodedName
            ? decodedName.charAt(0).toUpperCase() + decodedName.slice(1)
            : fullName;

    if (!realmSlug || !nameSlug)
        return displayName;

    const armoryUrl =
        `https://worldofwarcraft.blizzard.com/en-us/modern/${region}/armory/character/${realmSlug}/${nameSlug}`;

    return `<a href="${armoryUrl}" target="_blank" rel="noopener noreferrer">${displayName}</a>`;
}

//---------------------------------------

function buildPortraitCell(avatarUrl)
{
    if (!avatarUrl)
        return "";

    return `<img class="char-portrait" src="${avatarUrl}" alt="" onerror="this.style.display='none'">`;
}

//---------------------------------------

function buildRaceClassCell(race, playerClass, playerClassEnum)
{
    const color = CLASS_COLORS[playerClassEnum] || "inherit";

    return `<span class="race-name">${race}</span> `
        + `<span class="class-name" style="color:${color}">${playerClass}</span>`;
}

//---------------------------------------

function classNameHtml(playerClass, playerClassEnum)
{
    const color = CLASS_COLORS[playerClassEnum] || "inherit";

    return `<span style="color:${color}; font-weight:700;">${playerClass}</span>`;
}

//---------------------------------------

function formatDate(iso)
{
    if (!iso)
        return "-";

    try
    {
        const date = new Date(iso);

        return date.toLocaleDateString(undefined, {
            year: "numeric",
            month: "short",
            day: "numeric"
        });
    }
    catch (e)
    {
        return "-";
    }
}